package com.raghadsrazeen.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
