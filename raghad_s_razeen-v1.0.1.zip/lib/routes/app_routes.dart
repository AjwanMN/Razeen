import 'package:flutter/material.dart';
import 'package:raghad_s_razeen/presentation/frame_135_screen/frame_135_screen.dart';
import 'package:raghad_s_razeen/presentation/frame_134_screen/frame_134_screen.dart';
import 'package:raghad_s_razeen/presentation/frame_thirtyfour_screen/frame_thirtyfour_screen.dart';
import 'package:raghad_s_razeen/presentation/frame_fortynine_screen/frame_fortynine_screen.dart';
import 'package:raghad_s_razeen/presentation/frame_fortyeight_screen/frame_fortyeight_screen.dart';
import 'package:raghad_s_razeen/presentation/frame_137_screen/frame_137_screen.dart';
import 'package:raghad_s_razeen/presentation/frame_136_screen/frame_136_screen.dart';
import 'package:raghad_s_razeen/presentation/frame_133_screen/frame_133_screen.dart';
import 'package:raghad_s_razeen/presentation/frame_158_container_screen/frame_158_container_screen.dart';
import 'package:raghad_s_razeen/presentation/frame_164_screen/frame_164_screen.dart';
import 'package:raghad_s_razeen/presentation/frame_100_screen/frame_100_screen.dart';
import 'package:raghad_s_razeen/presentation/frame_103_screen/frame_103_screen.dart';
import 'package:raghad_s_razeen/presentation/frame_104_screen/frame_104_screen.dart';
import 'package:raghad_s_razeen/presentation/frame_105_screen/frame_105_screen.dart';
import 'package:raghad_s_razeen/presentation/frame_106_screen/frame_106_screen.dart';
import 'package:raghad_s_razeen/presentation/frame_112_screen/frame_112_screen.dart';
import 'package:raghad_s_razeen/presentation/frame_110_screen/frame_110_screen.dart';
import 'package:raghad_s_razeen/presentation/frame_113_screen/frame_113_screen.dart';
import 'package:raghad_s_razeen/presentation/frame_120_screen/frame_120_screen.dart';
import 'package:raghad_s_razeen/presentation/frame_121_screen/frame_121_screen.dart';
import 'package:raghad_s_razeen/presentation/frame_107_screen/frame_107_screen.dart';
import 'package:raghad_s_razeen/presentation/frame_108_screen/frame_108_screen.dart';
import 'package:raghad_s_razeen/presentation/frame_139_screen/frame_139_screen.dart';
import 'package:raghad_s_razeen/presentation/frame_138_screen/frame_138_screen.dart';
import 'package:raghad_s_razeen/presentation/frame_130_screen/frame_130_screen.dart';
import 'package:raghad_s_razeen/presentation/frame_146_screen/frame_146_screen.dart';
import 'package:raghad_s_razeen/presentation/frame_144_screen/frame_144_screen.dart';
import 'package:raghad_s_razeen/presentation/frame_116_screen/frame_116_screen.dart';
import 'package:raghad_s_razeen/presentation/frame_122_screen/frame_122_screen.dart';
import 'package:raghad_s_razeen/presentation/frame_123_screen/frame_123_screen.dart';
import 'package:raghad_s_razeen/presentation/frame_152_screen/frame_152_screen.dart';
import 'package:raghad_s_razeen/presentation/frame_156_screen/frame_156_screen.dart';
import 'package:raghad_s_razeen/presentation/frame_141_screen/frame_141_screen.dart';
import 'package:raghad_s_razeen/presentation/frame_140_screen/frame_140_screen.dart';
import 'package:raghad_s_razeen/presentation/frame_131_screen/frame_131_screen.dart';
import 'package:raghad_s_razeen/presentation/frame_159_screen/frame_159_screen.dart';
import 'package:raghad_s_razeen/presentation/frame_117_screen/frame_117_screen.dart';
import 'package:raghad_s_razeen/presentation/frame_124_screen/frame_124_screen.dart';
import 'package:raghad_s_razeen/presentation/frame_125_screen/frame_125_screen.dart';
import 'package:raghad_s_razeen/presentation/frame_153_screen/frame_153_screen.dart';
import 'package:raghad_s_razeen/presentation/frame_157_screen/frame_157_screen.dart';
import 'package:raghad_s_razeen/presentation/frame_143_screen/frame_143_screen.dart';
import 'package:raghad_s_razeen/presentation/frame_142_screen/frame_142_screen.dart';
import 'package:raghad_s_razeen/presentation/frame_132_screen/frame_132_screen.dart';
import 'package:raghad_s_razeen/presentation/frame_118_screen/frame_118_screen.dart';
import 'package:raghad_s_razeen/presentation/frame_126_screen/frame_126_screen.dart';
import 'package:raghad_s_razeen/presentation/frame_127_screen/frame_127_screen.dart';
import 'package:raghad_s_razeen/presentation/frame_119_screen/frame_119_screen.dart';
import 'package:raghad_s_razeen/presentation/frame_128_screen/frame_128_screen.dart';
import 'package:raghad_s_razeen/presentation/frame_129_screen/frame_129_screen.dart';
import 'package:raghad_s_razeen/presentation/frame_fortyfour_screen/frame_fortyfour_screen.dart';
import 'package:raghad_s_razeen/presentation/frame_ninetythree_screen/frame_ninetythree_screen.dart';
import 'package:raghad_s_razeen/presentation/frame_eighteen_screen/frame_eighteen_screen.dart';
import 'package:raghad_s_razeen/presentation/frame_sixtynine_screen/frame_sixtynine_screen.dart';
import 'package:raghad_s_razeen/presentation/frame_eightysix_screen/frame_eightysix_screen.dart';
import 'package:raghad_s_razeen/presentation/frame_thirtynine_screen/frame_thirtynine_screen.dart';
import 'package:raghad_s_razeen/presentation/frame_thirtyeight_screen/frame_thirtyeight_screen.dart';
import 'package:raghad_s_razeen/presentation/frame_thirtyseven_screen/frame_thirtyseven_screen.dart';
import 'package:raghad_s_razeen/presentation/frame_eightyfive_screen/frame_eightyfive_screen.dart';
import 'package:raghad_s_razeen/presentation/frame_eightyone_screen/frame_eightyone_screen.dart';
import 'package:raghad_s_razeen/presentation/frame_ninetynine_screen/frame_ninetynine_screen.dart';
import 'package:raghad_s_razeen/presentation/frame_ninetyeight_screen/frame_ninetyeight_screen.dart';
import 'package:raghad_s_razeen/presentation/frame_ninetyseven_screen/frame_ninetyseven_screen.dart';
import 'package:raghad_s_razeen/presentation/frame_five_screen/frame_five_screen.dart';
import 'package:raghad_s_razeen/presentation/frame_eight_screen/frame_eight_screen.dart';
import 'package:raghad_s_razeen/presentation/frame_nine_screen/frame_nine_screen.dart';
import 'package:raghad_s_razeen/presentation/frame_fourteen_screen/frame_fourteen_screen.dart';
import 'package:raghad_s_razeen/presentation/frame_fifteen_screen/frame_fifteen_screen.dart';
import 'package:raghad_s_razeen/presentation/frame_sixtytwo_screen/frame_sixtytwo_screen.dart';
import 'package:raghad_s_razeen/presentation/frame_fiftynine_screen/frame_fiftynine_screen.dart';
import 'package:raghad_s_razeen/presentation/frame_seventysix_screen/frame_seventysix_screen.dart';
import 'package:raghad_s_razeen/presentation/frame_eightyseven_screen/frame_eightyseven_screen.dart';
import 'package:raghad_s_razeen/presentation/frame_ninety_screen/frame_ninety_screen.dart';
import 'package:raghad_s_razeen/presentation/frame_eightynine_screen/frame_eightynine_screen.dart';
import 'package:raghad_s_razeen/presentation/frame_ninetysix_screen/frame_ninetysix_screen.dart';
import 'package:raghad_s_razeen/presentation/frame_ninetyfive_screen/frame_ninetyfive_screen.dart';
import 'package:raghad_s_razeen/presentation/frame_ninetyfour_screen/frame_ninetyfour_screen.dart';
import 'package:raghad_s_razeen/presentation/frame_thirtythree_screen/frame_thirtythree_screen.dart';
import 'package:raghad_s_razeen/presentation/frame_twentynine_screen/frame_twentynine_screen.dart';
import 'package:raghad_s_razeen/presentation/frame_thirtytwo_screen/frame_thirtytwo_screen.dart';
import 'package:raghad_s_razeen/presentation/frame_thirtysix_screen/frame_thirtysix_screen.dart';
import 'package:raghad_s_razeen/presentation/frame_thirtyfive_screen/frame_thirtyfive_screen.dart';
import 'package:raghad_s_razeen/presentation/app_navigation_screen/app_navigation_screen.dart';

class AppRoutes {
  static const String frame135Screen = '/frame_135_screen';

  static const String frame134Screen = '/frame_134_screen';

  static const String frameThirtyfourScreen = '/frame_thirtyfour_screen';

  static const String frameFortynineScreen = '/frame_fortynine_screen';

  static const String frameFortyeightScreen = '/frame_fortyeight_screen';

  static const String frame137Screen = '/frame_137_screen';

  static const String frame136Screen = '/frame_136_screen';

  static const String frame133Screen = '/frame_133_screen';

  static const String frame158Page = '/frame_158_page';

  static const String frame158ContainerScreen = '/frame_158_container_screen';

  static const String frame164Screen = '/frame_164_screen';

  static const String frame100Screen = '/frame_100_screen';

  static const String frame103Screen = '/frame_103_screen';

  static const String frame104Screen = '/frame_104_screen';

  static const String frame105Screen = '/frame_105_screen';

  static const String frame106Screen = '/frame_106_screen';

  static const String frame112Screen = '/frame_112_screen';

  static const String frame110Screen = '/frame_110_screen';

  static const String frame113Screen = '/frame_113_screen';

  static const String frame120Screen = '/frame_120_screen';

  static const String frame121Screen = '/frame_121_screen';

  static const String frame107Screen = '/frame_107_screen';

  static const String frame108Screen = '/frame_108_screen';

  static const String frame139Screen = '/frame_139_screen';

  static const String frame138Screen = '/frame_138_screen';

  static const String frame130Screen = '/frame_130_screen';

  static const String frame146Screen = '/frame_146_screen';

  static const String frame144Screen = '/frame_144_screen';

  static const String frame116Screen = '/frame_116_screen';

  static const String frame122Screen = '/frame_122_screen';

  static const String frame123Screen = '/frame_123_screen';

  static const String frame152Screen = '/frame_152_screen';

  static const String frame156Screen = '/frame_156_screen';

  static const String frame141Screen = '/frame_141_screen';

  static const String frame140Screen = '/frame_140_screen';

  static const String frame131Screen = '/frame_131_screen';

  static const String frame159Screen = '/frame_159_screen';

  static const String frame117Screen = '/frame_117_screen';

  static const String frame124Screen = '/frame_124_screen';

  static const String frame125Screen = '/frame_125_screen';

  static const String frame153Screen = '/frame_153_screen';

  static const String frame157Screen = '/frame_157_screen';

  static const String frame143Screen = '/frame_143_screen';

  static const String frame142Screen = '/frame_142_screen';

  static const String frame132Screen = '/frame_132_screen';

  static const String frame118Screen = '/frame_118_screen';

  static const String frame126Screen = '/frame_126_screen';

  static const String frame127Screen = '/frame_127_screen';

  static const String frame119Screen = '/frame_119_screen';

  static const String frame128Screen = '/frame_128_screen';

  static const String frame129Screen = '/frame_129_screen';

  static const String frameFortyfourScreen = '/frame_fortyfour_screen';

  static const String frameNinetythreeScreen = '/frame_ninetythree_screen';

  static const String frameEighteenScreen = '/frame_eighteen_screen';

  static const String frameSixtynineScreen = '/frame_sixtynine_screen';

  static const String frameEightysixScreen = '/frame_eightysix_screen';

  static const String frameThirtynineScreen = '/frame_thirtynine_screen';

  static const String frameThirtyeightScreen = '/frame_thirtyeight_screen';

  static const String frameThirtysevenScreen = '/frame_thirtyseven_screen';

  static const String frameEightyfiveScreen = '/frame_eightyfive_screen';

  static const String frameEightyoneScreen = '/frame_eightyone_screen';

  static const String frameNinetynineScreen = '/frame_ninetynine_screen';

  static const String frameNinetyeightScreen = '/frame_ninetyeight_screen';

  static const String frameNinetysevenScreen = '/frame_ninetyseven_screen';

  static const String frameFiveScreen = '/frame_five_screen';

  static const String frameEightScreen = '/frame_eight_screen';

  static const String frameNineScreen = '/frame_nine_screen';

  static const String frameFourteenScreen = '/frame_fourteen_screen';

  static const String frameFifteenScreen = '/frame_fifteen_screen';

  static const String frameSixtytwoScreen = '/frame_sixtytwo_screen';

  static const String frameFiftynineScreen = '/frame_fiftynine_screen';

  static const String frameSeventysixScreen = '/frame_seventysix_screen';

  static const String frameEightysevenScreen = '/frame_eightyseven_screen';

  static const String frameNinetyScreen = '/frame_ninety_screen';

  static const String frameEightynineScreen = '/frame_eightynine_screen';

  static const String frameNinetysixScreen = '/frame_ninetysix_screen';

  static const String frameNinetyfiveScreen = '/frame_ninetyfive_screen';

  static const String frameNinetyfourScreen = '/frame_ninetyfour_screen';

  static const String frameThirtythreeScreen = '/frame_thirtythree_screen';

  static const String frameTwentynineScreen = '/frame_twentynine_screen';

  static const String frameThirtytwoScreen = '/frame_thirtytwo_screen';

  static const String frameThirtysixScreen = '/frame_thirtysix_screen';

  static const String frameThirtyfiveScreen = '/frame_thirtyfive_screen';

  static const String appNavigationScreen = '/app_navigation_screen';

  static Map<String, WidgetBuilder> routes = {
    frame135Screen: (context) => Frame135Screen(),
    frame134Screen: (context) => Frame134Screen(),
    frameThirtyfourScreen: (context) => FrameThirtyfourScreen(),
    frameFortynineScreen: (context) => FrameFortynineScreen(),
    frameFortyeightScreen: (context) => FrameFortyeightScreen(),
    frame137Screen: (context) => Frame137Screen(),
    frame136Screen: (context) => Frame136Screen(),
    frame133Screen: (context) => Frame133Screen(),
    frame158ContainerScreen: (context) => Frame158ContainerScreen(),
    frame164Screen: (context) => Frame164Screen(),
    frame100Screen: (context) => Frame100Screen(),
    frame103Screen: (context) => Frame103Screen(),
    frame104Screen: (context) => Frame104Screen(),
    frame105Screen: (context) => Frame105Screen(),
    frame106Screen: (context) => Frame106Screen(),
    frame112Screen: (context) => Frame112Screen(),
    frame110Screen: (context) => Frame110Screen(),
    frame113Screen: (context) => Frame113Screen(),
    frame120Screen: (context) => Frame120Screen(),
    frame121Screen: (context) => Frame121Screen(),
    frame107Screen: (context) => Frame107Screen(),
    frame108Screen: (context) => Frame108Screen(),
    frame139Screen: (context) => Frame139Screen(),
    frame138Screen: (context) => Frame138Screen(),
    frame130Screen: (context) => Frame130Screen(),
    frame146Screen: (context) => Frame146Screen(),
    frame144Screen: (context) => Frame144Screen(),
    frame116Screen: (context) => Frame116Screen(),
    frame122Screen: (context) => Frame122Screen(),
    frame123Screen: (context) => Frame123Screen(),
    frame152Screen: (context) => Frame152Screen(),
    frame156Screen: (context) => Frame156Screen(),
    frame141Screen: (context) => Frame141Screen(),
    frame140Screen: (context) => Frame140Screen(),
    frame131Screen: (context) => Frame131Screen(),
    frame159Screen: (context) => Frame159Screen(),
    frame117Screen: (context) => Frame117Screen(),
    frame124Screen: (context) => Frame124Screen(),
    frame125Screen: (context) => Frame125Screen(),
    frame153Screen: (context) => Frame153Screen(),
    frame157Screen: (context) => Frame157Screen(),
    frame143Screen: (context) => Frame143Screen(),
    frame142Screen: (context) => Frame142Screen(),
    frame132Screen: (context) => Frame132Screen(),
    frame118Screen: (context) => Frame118Screen(),
    frame126Screen: (context) => Frame126Screen(),
    frame127Screen: (context) => Frame127Screen(),
    frame119Screen: (context) => Frame119Screen(),
    frame128Screen: (context) => Frame128Screen(),
    frame129Screen: (context) => Frame129Screen(),
    frameFortyfourScreen: (context) => FrameFortyfourScreen(),
    frameNinetythreeScreen: (context) => FrameNinetythreeScreen(),
    frameEighteenScreen: (context) => FrameEighteenScreen(),
    frameSixtynineScreen: (context) => FrameSixtynineScreen(),
    frameEightysixScreen: (context) => FrameEightysixScreen(),
    frameThirtynineScreen: (context) => FrameThirtynineScreen(),
    frameThirtyeightScreen: (context) => FrameThirtyeightScreen(),
    frameThirtysevenScreen: (context) => FrameThirtysevenScreen(),
    frameEightyfiveScreen: (context) => FrameEightyfiveScreen(),
    frameEightyoneScreen: (context) => FrameEightyoneScreen(),
    frameNinetynineScreen: (context) => FrameNinetynineScreen(),
    frameNinetyeightScreen: (context) => FrameNinetyeightScreen(),
    frameNinetysevenScreen: (context) => FrameNinetysevenScreen(),
    frameFiveScreen: (context) => FrameFiveScreen(),
    frameEightScreen: (context) => FrameEightScreen(),
    frameNineScreen: (context) => FrameNineScreen(),
    frameFourteenScreen: (context) => FrameFourteenScreen(),
    frameFifteenScreen: (context) => FrameFifteenScreen(),
    frameSixtytwoScreen: (context) => FrameSixtytwoScreen(),
    frameFiftynineScreen: (context) => FrameFiftynineScreen(),
    frameSeventysixScreen: (context) => FrameSeventysixScreen(),
    frameEightysevenScreen: (context) => FrameEightysevenScreen(),
    frameNinetyScreen: (context) => FrameNinetyScreen(),
    frameEightynineScreen: (context) => FrameEightynineScreen(),
    frameNinetysixScreen: (context) => FrameNinetysixScreen(),
    frameNinetyfiveScreen: (context) => FrameNinetyfiveScreen(),
    frameNinetyfourScreen: (context) => FrameNinetyfourScreen(),
    frameThirtythreeScreen: (context) => FrameThirtythreeScreen(),
    frameTwentynineScreen: (context) => FrameTwentynineScreen(),
    frameThirtytwoScreen: (context) => FrameThirtytwoScreen(),
    frameThirtysixScreen: (context) => FrameThirtysixScreen(),
    frameThirtyfiveScreen: (context) => FrameThirtyfiveScreen(),
    appNavigationScreen: (context) => AppNavigationScreen()
  };
}
